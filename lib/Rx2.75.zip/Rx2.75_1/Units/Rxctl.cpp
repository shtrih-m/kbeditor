//---------------------------------------------------------------------------
// Delphi VCL Extensions (RX)
// Copyright (c) 1998 Master-Bank
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
USEPACKAGE("vcl35.bpi");
USEPACKAGE("vclx35.bpi");
USEUNIT("Rxctrls.pas");
USEUNIT("Rxgrids.pas");
USEUNIT("Curredit.pas");
USEUNIT("Tooledit.pas");
USEUNIT("Dateutil.pas");
USEUNIT("Rxsplit.pas");
USEUNIT("Rxslider.pas");
USEUNIT("Rxclock.pas");
USEUNIT("Animate.pas");
USEUNIT("Rxspin.pas");
USEUNIT("RxRichEd.pas");
USEUNIT("Rxswitch.pas");
USEUNIT("Rxdice.pas");
USEUNIT("ClipMon.pas");
USEUNIT("Vclutils.pas");
USEUNIT("Anifile.pas");
USEUNIT("Icolist.pas");
USEUNIT("Objstr.pas");
USEUNIT("Rxcombos.pas");
USEUNIT("Pickdate.pas");
USEUNIT("Maxmin.pas");
USEUNIT("Rxconst.pas");
USEUNIT("Rxcconst.pas");
USEUNIT("Apputils.pas");
USEUNIT("Strutils.pas");
USEUNIT("Fileutil.pas");
USEUNIT("Rxtimer.pas");
USEUNIT("Rxhook.pas");
USEUNIT("Placemnt.pas");
USEUNIT("Rxprops.pas");
USEUNIT("Rxprgrss.pas");
USEUNIT("Rxhints.pas");
USEUNIT("Rxcalc.pas");
USEUNIT("Boxprocs.pas");
USEUNIT("Clipicon.pas");
USEUNIT("Rxgraph.pas");
USEUNIT("PicClip.pas");
USEUNIT("DualList.pas");
USEUNIT("FDualLst.pas");
USEUNIT("ClipView.pas");
USEUNIT("Speedbar.pas");
USEUNIT("SbSetup.pas");
USEUNIT("PageMngr.pas");
USEUNIT("MrgMngr.pas");
USEUNIT("StrHlder.pas");
USEUNIT("AppEvent.pas");
USEUNIT("TimerLst.pas");
USEUNIT("MRUList.pas");
USEUNIT("RxIni.pas");
USEUNIT("RxShell.pas");
USEUNIT("Parsing.pas");
USEUNIT("RxMenus.pas");
USEUNIT("RxNotify.pas");
USEUNIT("RxGrdCpt.pas");
USEUNIT("SplshWnd.pas");
USEUNIT("DataConv.pas");
USEUNIT("RxTConst.pas");
USEUNIT("Ole2Auto.pas");
USEUNIT("RxVerInf.pas");
USEUNIT("ExcptDlg.pas");
USEUNIT("Str16.pas");
USEUNIT("Rxgconst.pas");
USEUNIT("Rxgif.pas");
USEUNIT("Gifctrl.pas");
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
//   Package source.
//---------------------------------------------------------------------------
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void*)
{
    return 1;
}
//---------------------------------------------------------------------------
