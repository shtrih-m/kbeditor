These are the modified files that are used to build the want.exe used to compile the relase zips for JVCL. Download want from 
sourceforge and replace the appropriate files with these.